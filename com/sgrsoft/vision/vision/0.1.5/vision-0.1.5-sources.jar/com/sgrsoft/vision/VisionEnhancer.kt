package com.sgrsoft.vision

import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer

// Imperative controller — mirror of the web enhance() handle / iOS VisionEnhancer.
// Attaches the GL effect to an ExoPlayer, maps options -> uniforms/CNN layers, and
// gates effects on license verification (packageName-bound) when a licenseKey is set.

// 낙관적 라이선스 게이팅: 효과를 먼저 켜고 이 grace 후 검증한다.
private const val LICENSE_GRACE_MS = 2000L

@UnstableApi
class VisionEnhancer(
    private val player: ExoPlayer,
    options: VisionOptions,
    private val context: Context? = null,
    deviceInfo: DeviceInfo = DeviceInfo.default(),
    private val onLicense: ((LicenseState) -> Unit)? = null,
) {
    private var options = options
    private val pipeline = EnhancementPipeline(options, deviceInfo)
    private val state = RenderState()
    private val main = Handler(Looper.getMainLooper())

    // License gating: until verified, `licensed` is false -> passthrough (original plays).
    private var licensed = true
    var licenseState: LicenseState = LicenseState.none
        private set

    // DRM 폴백: 보호(암호화) 콘텐츠면 이펙트를 떼어 OS 가 원본을 그대로 재생(검정 방지).
    private var effectsAttached = false
    var drmFallback: Boolean = false
        private set
    private val playerListener = object : Player.Listener {
        override fun onTracksChanged(tracks: Tracks) { syncEffectAttachment() }
    }

    init {
        val key = options.licenseKey
        if (key != null && isDevBuild()) {
            // 개발(디버그) 빌드 — 웹 localhost 면제처럼 라이선스 검증을 건너뛴다(릴리스 빌드만 검증).
            licensed = true
            licenseState = LicenseState.ok
            rebuild()
            main.post { onLicense?.invoke(LicenseState.ok) }
        } else if (key != null) {
            // 낙관적 게이팅: 효과를 먼저 켜고 2초 뒤 검증한다(실패 시 effect OFF).
            // app id 는 LicenseClient 가 OS(프로세스)에서 직접 얻고, context.packageName 은
            // 폴백으로만 전달 — 다른 앱 라이선스로 위조 불가.
            licensed = true
            licenseState = LicenseState.pending
            rebuild()
            startLicense(key, context?.applicationContext?.packageName)
        } else {
            licensed = true
            licenseState = LicenseState.none
            rebuild()
        }
        player.addListener(playerListener)
        syncEffectAttachment()   // 현재 트랙 기준으로 이펙트 부착(클리어면 부착, DRM 이면 미부착)
    }

    /** DRM(secure) 콘텐츠면 GL 이펙트를 떼어 원본 재생, 클리어면 부착. onTracksChanged 마다 재평가. */
    private fun syncEffectAttachment() {
        val protectedNow = isProtectedContent()
        drmFallback = protectedNow
        if (protectedNow) {
            if (effectsAttached) { player.setVideoEffects(emptyList()); effectsAttached = false }
        } else if (!effectsAttached) {
            player.setVideoEffects(listOf(VisionGlEffect(state))); effectsAttached = true
        }
    }

    /** 선택된 비디오 트랙이 암호화(DRM)되어 있는지 — Media3 Effect(GL)는 secure surface 처리 불가. */
    private fun isProtectedContent(): Boolean {
        for (group in player.currentTracks.groups) {
            if (group.type != C.TRACK_TYPE_VIDEO) continue
            for (i in 0 until group.length) {
                if (group.getTrackFormat(i).drmInitData != null) return true
            }
        }
        return false
    }

    /** Update options live (no effect rebuild — the effect reads shared state). */
    fun update(newOptions: VisionOptions) {
        options = newOptions
        pipeline.update(newOptions)
        rebuild()
    }

    fun setEnabled(enabled: Boolean) = update(options.copy(enabled = enabled))

    /** 동시 비교(CNN 적용 좌 vs 미적용 우) 분할 위치. <0(예: -1f)이면 비활성. */
    fun setCompareSplit(split: Float) { state.compareSplit = split }

    fun getState(): VisionState = VisionState(
        enabled = licensed && pipeline.isEnabled && !drmFallback,
        profile = options.profile,
        rendererKind = "gles",
        license = licenseState,
        uniforms = pipeline.uniforms,
        drmFallback = drmFallback,
    )

    fun destroy() {
        main.removeCallbacksAndMessages(null)   // 대기 중인 라이선스 검증 취소
        player.removeListener(playerListener)
        player.setVideoEffects(emptyList())
        effectsAttached = false
    }

    private fun rebuild() {
        // Passthrough (default uniforms = no-op) until the license check passes.
        if (licensed) {
            state.uniforms = pipeline.uniforms
            state.layers = options.cnn?.layers ?: emptyList()
        } else {
            state.uniforms = EnhancementUniforms()
            state.layers = emptyList()
        }
    }

    /** 디버그(릴리스 아님) 빌드 여부 — 웹 localhost 면제 대응. 릴리스 APK 는 debuggable=false. */
    private fun isDevBuild(): Boolean {
        val ai = context?.applicationInfo ?: return false
        return (ai.flags and android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE) != 0
    }

    private fun startLicense(key: String, fallbackPackageName: String?) {
        // 효과를 먼저 켠 뒤 2초 grace 후 검증/적용(실패면 applyLicense 가 효과를 끔).
        main.postDelayed({
            LicenseClient.cached(key)?.let { applyLicense(it); return@postDelayed }
            Thread {
                val result = LicenseClient.verify(key, fallbackPackageName)
                main.post { applyLicense(result) }
            }.apply { isDaemon = true }.start()
        }, LICENSE_GRACE_MS)
    }

    private fun applyLicense(result: LicenseResult) {
        licensed = result.valid
        licenseState = if (result.valid) LicenseState.ok else LicenseState.invalid
        rebuild()
        onLicense?.invoke(licenseState)
    }
}

data class VisionState(
    val enabled: Boolean,
    val profile: VisionProfile?,
    val rendererKind: String,
    val license: LicenseState,
    val uniforms: EnhancementUniforms,
    val drmFallback: Boolean = false,
)
