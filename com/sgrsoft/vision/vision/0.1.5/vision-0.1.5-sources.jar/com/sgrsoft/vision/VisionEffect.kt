package com.sgrsoft.vision

import android.content.Context
import android.opengl.GLES20
import androidx.media3.common.util.Size
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BaseGlShaderProgram
import androidx.media3.effect.GlEffect
import androidx.media3.effect.GlShaderProgram

/** Live render state read by the GL effect each frame (so option changes apply without
 *  rebuilding the effect). Written by VisionEnhancer, read on the GL thread. */
class RenderState {
    @Volatile var uniforms: EnhancementUniforms = EnhancementUniforms()
    @Volatile var layers: List<CnnLayer> = emptyList()
    // 동시 비교(CNN 적용 좌 vs 미적용 우) 분할 위치. <0 이면 비활성.
    @Volatile var compareSplit: Float = -1f
}

/** Media3 effect that runs the SGR Vision pass-chain on each decoded video frame. */
@UnstableApi
class VisionGlEffect(private val state: RenderState) : GlEffect {
    override fun toGlShaderProgram(context: Context, useHdr: Boolean): GlShaderProgram =
        VisionShaderProgram(useHdr, state)
}

@UnstableApi
private class VisionShaderProgram(
    useHdr: Boolean,
    private val state: RenderState,
) : BaseGlShaderProgram(useHdr, /* texturePoolCapacity= */ 1) {

    private val renderer = GlRenderer()
    private var prepared = false
    private var outW = 0
    private var outH = 0

    override fun configure(inputWidth: Int, inputHeight: Int): Size {
        if (!prepared) { renderer.setup(); prepared = true }
        outW = inputWidth; outH = inputHeight
        return Size(inputWidth, inputHeight)
    }

    override fun drawFrame(inputTexId: Int, presentationTimeUs: Long) {
        renderer.setUniforms(state.uniforms)
        renderer.setCnnLayers(state.layers)
        renderer.setCompareSplit(state.compareSplit)
        // The base class focuses the output framebuffer before calling drawFrame.
        val fbo = IntArray(1)
        GLES20.glGetIntegerv(GLES20.GL_FRAMEBUFFER_BINDING, fbo, 0)
        renderer.renderChain(inputTexId, outW, outH, fbo[0], outW, outH)
    }

    override fun release() {
        super.release()
        if (prepared) renderer.release()
    }
}
