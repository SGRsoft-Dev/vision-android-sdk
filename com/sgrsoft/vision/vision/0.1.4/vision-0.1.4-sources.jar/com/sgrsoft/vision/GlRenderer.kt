package com.sgrsoft.vision

import android.opengl.GLES20
import android.opengl.GLES30
import android.opengl.GLES31
import java.nio.ByteBuffer
import java.nio.ByteOrder

// OpenGL ES port of the enhancement render pass-chain (web WebGL / iOS Metal):
//   input -> [upscale: bilinear|lanczos|FSR EASU] -> [RCAS] -> combined -> output
// Combined runs cleanup→sharpen→anime→darkLift→localContrast→contrast→gamma→scanline.
// CNN (ES 3.1 compute) lands in a later phase. Assumes a current EGL context.
class GlRenderer {

    private lateinit var combined: Program
    private lateinit var bilinear: Program
    private lateinit var lanczos: Program
    private lateinit var easu: Program
    private lateinit var rcas: Program
    private var quadVbo = 0
    private val pool = TexFboPool()
    private var uniforms = EnhancementUniforms()

    // CNN (ES 3.1 compute). Null when the context lacks compute support.
    private var cnnProgram = 0
    private var cnnLayers: List<CnnLayer> = emptyList()

    fun setUniforms(u: EnhancementUniforms) { uniforms = u }
    fun setCnnLayers(layers: List<CnnLayer>) { cnnLayers = layers }

    fun setup() {
        val quad = floatArrayOf(
            -1f, -1f, 0f, 0f,
             1f, -1f, 1f, 0f,
            -1f,  1f, 0f, 1f,
             1f,  1f, 1f, 1f,
        )
        val buf = ByteBuffer.allocateDirect(quad.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        buf.put(quad).position(0)
        val ids = IntArray(1); GLES20.glGenBuffers(1, ids, 0); quadVbo = ids[0]
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, quadVbo)
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, quad.size * 4, buf, GLES20.GL_STATIC_DRAW)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)

        val vsrc = loadShader("vertex.glsl")
        combined = Program(vsrc, loadShader("combined.frag"))
        bilinear = Program(vsrc, loadShader("upscaleBilinear.frag"))
        lanczos = Program(vsrc, loadShader("lanczos_upscale.frag"))
        easu = Program(vsrc, loadShader("fsr_easu.frag"))
        rcas = Program(vsrc, loadShader("fsr_rcas.frag"))
        // CNN needs ES 3.1 compute. Probe the version first — calling GLES31 on a
        // lower context raises GL_INVALID_ENUM that would poison the host pipeline
        // (e.g. Media3's). On unsupported contexts CNN is skipped (web-WebGL parity).
        cnnProgram = if (supportsCompute()) compileCompute(loadShader("cnn_layer.comp")) else 0
        drainGlErrors()
    }

    private fun supportsCompute(): Boolean {
        val v = GLES20.glGetString(GLES20.GL_VERSION) ?: return false
        val m = Regex("OpenGL ES (\\d+)\\.(\\d+)").find(v) ?: return false
        val major = m.groupValues[1].toInt(); val minor = m.groupValues[2].toInt()
        return major > 3 || (major == 3 && minor >= 1)
    }

    private fun drainGlErrors() { while (GLES20.glGetError() != GLES20.GL_NO_ERROR) { /* clear */ } }

    /** Whether CNN compute is available (ES 3.1 context with compute). */
    val cnnAvailable: Boolean get() = cnnProgram != 0

    /** Combined pass only (input and output share size). */
    fun renderCombined(inputTex: Int, outputFbo: Int, width: Int, height: Int) {
        drawCombined(inputTex, outputFbo, width, height, width, height, sharpenAtten = 1.0)
    }

    /** Full pass-chain: input -> [upscale] -> [rcas] -> combined -> output. */
    fun renderChain(inputTex: Int, inW: Int, inH: Int, outputFbo: Int, outW: Int, outH: Int) {
        val u = uniforms
        val atten = EnhancementPipeline.scaleAttenuation(inW.toDouble(), inH.toDouble(), outW.toDouble(), outH.toDouble())
        var curTex = inputTex; var curW = inW; var curH = inH
        val scratch = ArrayList<Scratch>()

        // 1) Upscale.
        if (u.upscaleEnabled && u.upscaleAlgorithm != UpscaleAlgorithm.none) {
            val s = pool.acquire(outW, outH); scratch += s
            val prog = when (u.upscaleAlgorithm) {
                UpscaleAlgorithm.fsr -> easu
                UpscaleAlgorithm.lanczos -> lanczos
                else -> bilinear // bilinear / nearest baseline
            }
            val srcW = curW; val srcH = curH; val tex = curTex
            drawTo(prog, s.fbo, outW, outH) {
                bindSampler(prog, tex)
                if (prog === lanczos || prog === easu) {
                    GLES20.glUniform2f(prog.loc("u_inputSize"), srcW.toFloat(), srcH.toFloat())
                    GLES20.glUniform2f(prog.loc("u_outputSize"), outW.toFloat(), outH.toFloat())
                }
            }
            curTex = s.tex; curW = outW; curH = outH
        }

        // 2) RCAS.
        if (u.rcasEnabled) {
            val s = pool.acquire(curW, curH); scratch += s
            val tex = curTex; val cw = curW; val ch = curH
            drawTo(rcas, s.fbo, curW, curH) {
                bindSampler(rcas, tex)
                GLES20.glUniform2f(rcas.loc("u_texelSize"), 1f / cw, 1f / ch)
                GLES20.glUniform1f(rcas.loc("u_rcasSharpness"), (u.rcasSharpness * atten).toFloat())
            }
            curTex = s.tex
        }

        // 3) CNN compute stage(s) — cnn1 (default sharpen) then injected multi-layer.
        if (cnnProgram != 0) {
            if (u.cnn1Enabled) {
                val s = pool.acquire(curW, curH); scratch += s
                dispatchCnn(curTex, s.tex, curW, curH, CnnWeights.cnn1DefaultWeights(), isLast = true)
                curTex = s.tex
            }
            if (cnnLayers.isNotEmpty()) {
                val n = cnnLayers.size
                for ((i, layer) in cnnLayers.withIndex()) {
                    if (layer.weights.size < CnnWeights.FLOATS_PER_LAYER) break
                    val s = pool.acquire(curW, curH); scratch += s
                    dispatchCnn(curTex, s.tex, curW, curH, layer.weights, isLast = i == n - 1)
                    curTex = s.tex
                }
            }
        }

        // 4) Combined final -> output.
        drawCombined(curTex, outputFbo, outW, outH, curW, curH, sharpenAtten = atten)

        pool.release(scratch)
    }

    private fun dispatchCnn(inputTex: Int, outImage: Int, w: Int, h: Int, weights: FloatArray, isLast: Boolean) {
        GLES31.glUseProgram(cnnProgram)
        GLES31.glActiveTexture(GLES31.GL_TEXTURE0)
        GLES31.glBindTexture(GLES31.GL_TEXTURE_2D, inputTex)
        GLES31.glUniform1i(GLES31.glGetUniformLocation(cnnProgram, "uIn"), 0)
        GLES31.glUniform1fv(GLES31.glGetUniformLocation(cnnProgram, "W"), CnnWeights.FLOATS_PER_LAYER, weights, 0)
        GLES31.glUniform1i(GLES31.glGetUniformLocation(cnnProgram, "uIsLast"), if (isLast) 1 else 0)
        GLES31.glBindImageTexture(0, outImage, 0, false, 0, GLES31.GL_WRITE_ONLY, GLES30.GL_RGBA8)
        GLES31.glDispatchCompute((w + 15) / 16, (h + 15) / 16, 1)
        GLES31.glMemoryBarrier(GLES31.GL_SHADER_IMAGE_ACCESS_BARRIER_BIT or GLES31.GL_TEXTURE_FETCH_BARRIER_BIT)
    }

    private fun compileCompute(src: String): Int {
        val cs = GLES31.glCreateShader(GLES31.GL_COMPUTE_SHADER)
        if (cs == 0) return 0
        GLES31.glShaderSource(cs, src); GLES31.glCompileShader(cs)
        val ok = IntArray(1); GLES31.glGetShaderiv(cs, GLES31.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) { GLES31.glDeleteShader(cs); return 0 } // no compute support -> skip CNN
        val p = GLES31.glCreateProgram()
        GLES31.glAttachShader(p, cs); GLES31.glLinkProgram(p)
        GLES31.glGetProgramiv(p, GLES31.GL_LINK_STATUS, ok, 0)
        GLES31.glDeleteShader(cs)
        if (ok[0] == 0) { GLES31.glDeleteProgram(p); return 0 }
        return p
    }

    fun release() {
        if (quadVbo != 0) GLES20.glDeleteBuffers(1, intArrayOf(quadVbo), 0)
        if (::combined.isInitialized) listOf(combined, bilinear, lanczos, easu, rcas).forEach { it.release() }
        if (cnnProgram != 0) GLES20.glDeleteProgram(cnnProgram)
        pool.clear()
        quadVbo = 0; cnnProgram = 0
    }

    private fun drawCombined(inputTex: Int, fbo: Int, vpW: Int, vpH: Int, srcW: Int, srcH: Int, sharpenAtten: Double) {
        drawTo(combined, fbo, vpW, vpH) {
            bindSampler(combined, inputTex)
            val u = uniforms
            GLES20.glUniform2f(combined.loc("u_texelSize"), 1f / srcW, 1f / srcH)
            GLES20.glUniform2f(combined.loc("u_resolution"), vpW.toFloat(), vpH.toFloat())
            GLES20.glUniform1f(combined.loc("u_sharpen"), (u.sharpen * sharpenAtten).toFloat())
            GLES20.glUniform1f(combined.loc("u_contrast"), u.contrast.toFloat())
            GLES20.glUniform1f(combined.loc("u_cleanup"), u.cleanup.toFloat())
            GLES20.glUniform1f(combined.loc("u_anime"), u.anime.toFloat())
            GLES20.glUniform1f(combined.loc("u_gamma"), u.gamma.toFloat())
            GLES20.glUniform1f(combined.loc("u_localContrast"), u.localContrast.toFloat())
            GLES20.glUniform1f(combined.loc("u_darkLift"), u.darkLift.toFloat())
            GLES20.glUniform1f(combined.loc("u_scanlineIntensity"), u.scanlineIntensity.toFloat())
            GLES20.glUniform1f(combined.loc("u_scanlineSpacing"), u.scanlineSpacing.toFloat())
        }
    }

    private inline fun drawTo(prog: Program, fbo: Int, w: Int, h: Int, setUniforms: () -> Unit) {
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, fbo)
        GLES20.glViewport(0, 0, w, h)
        GLES20.glClearColor(0f, 0f, 0f, 1f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        GLES20.glUseProgram(prog.id)
        setUniforms()
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, quadVbo)
        GLES20.glEnableVertexAttribArray(prog.aPosition)
        GLES20.glVertexAttribPointer(prog.aPosition, 2, GLES20.GL_FLOAT, false, 16, 0)
        GLES20.glEnableVertexAttribArray(prog.aTexCoord)
        GLES20.glVertexAttribPointer(prog.aTexCoord, 2, GLES20.GL_FLOAT, false, 16, 8)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GLES20.glDisableVertexAttribArray(prog.aPosition)
        GLES20.glDisableVertexAttribArray(prog.aTexCoord)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0)
    }

    private fun bindSampler(prog: Program, tex: Int) {
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, tex)
        GLES20.glUniform1i(prog.loc("u_sampler"), 0)
    }

    private fun loadShader(name: String): String =
        (GlRenderer::class.java.getResourceAsStream("/shaders/$name")
            ?: error("SGRVision: shader resource /shaders/$name missing"))
            .bufferedReader().use { it.readText() }
}

/** Compiled program + attribute/uniform location cache. */
internal class Program(vertexSrc: String, fragSrc: String) {
    val id: Int
    val aPosition: Int
    val aTexCoord: Int
    private val uniformLoc = HashMap<String, Int>()

    init {
        val vs = compile(GLES20.GL_VERTEX_SHADER, vertexSrc)
        val fs = compile(GLES20.GL_FRAGMENT_SHADER, fragSrc)
        id = GLES20.glCreateProgram()
        GLES20.glAttachShader(id, vs); GLES20.glAttachShader(id, fs)
        GLES20.glLinkProgram(id)
        val ok = IntArray(1); GLES20.glGetProgramiv(id, GLES20.GL_LINK_STATUS, ok, 0)
        check(ok[0] != 0) { "program link failed: ${GLES20.glGetProgramInfoLog(id)}" }
        GLES20.glDeleteShader(vs); GLES20.glDeleteShader(fs)
        aPosition = GLES20.glGetAttribLocation(id, "a_position")
        aTexCoord = GLES20.glGetAttribLocation(id, "a_texCoord")
    }

    fun loc(name: String): Int = uniformLoc.getOrPut(name) { GLES20.glGetUniformLocation(id, name) }
    fun release() { GLES20.glDeleteProgram(id) }

    private fun compile(type: Int, src: String): Int {
        val s = GLES20.glCreateShader(type)
        GLES20.glShaderSource(s, src); GLES20.glCompileShader(s)
        val ok = IntArray(1); GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0)
        check(ok[0] != 0) { "shader compile failed: ${GLES20.glGetShaderInfoLog(s)}\n$src" }
        return s
    }
}

internal data class Scratch(val tex: Int, val fbo: Int, val w: Int, val h: Int)

/** Reuses offscreen (texture + FBO) targets across frames, keyed by size. */
internal class TexFboPool {
    private val free = HashMap<Long, ArrayDeque<Scratch>>()
    private val all = ArrayList<Scratch>()
    private fun key(w: Int, h: Int) = (w.toLong() shl 32) or (h.toLong() and 0xffffffffL)

    fun acquire(w: Int, h: Int): Scratch {
        free[key(w, h)]?.let { if (it.isNotEmpty()) return it.removeLast() }
        val tex = IntArray(1); GLES20.glGenTextures(1, tex, 0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, tex[0])
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        // Immutable RGBA8 storage so scratch can serve as render target, sampled texture,
        // AND CNN image-store target (ES 3.1 imageStore requires immutable, image-format).
        GLES30.glTexStorage2D(GLES30.GL_TEXTURE_2D, 1, GLES30.GL_RGBA8, w, h)
        val fbo = IntArray(1); GLES20.glGenFramebuffers(1, fbo, 0)
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, fbo[0])
        GLES20.glFramebufferTexture2D(GLES20.GL_FRAMEBUFFER, GLES20.GL_COLOR_ATTACHMENT0, GLES20.GL_TEXTURE_2D, tex[0], 0)
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0)
        return Scratch(tex[0], fbo[0], w, h).also { all += it }
    }

    fun release(items: List<Scratch>) {
        for (s in items) free.getOrPut(key(s.w, s.h)) { ArrayDeque() }.addLast(s)
    }

    fun clear() {
        for (s in all) {
            GLES20.glDeleteFramebuffers(1, intArrayOf(s.fbo), 0)
            GLES20.glDeleteTextures(1, intArrayOf(s.tex), 0)
        }
        all.clear(); free.clear()
    }
}
