package com.sgrsoft.vision

import java.nio.ByteBuffer
import java.nio.ByteOrder

// CNN weights — identical .bin layout to the web SDK (cnnWeights.ts) and iOS CnnWeights.
// 81 floats per layer: [c_out][c_in][k], k = (dy+1)*3 + (dx+1), little-endian f32 contiguous.
object CnnWeights {
    const val FLOATS_PER_LAYER = 81

    /** Parse a contiguous little-endian f32 buffer into [layerCount] CnnLayers. */
    fun parse(data: ByteArray, layerCount: Int): List<CnnLayer> {
        val need = FLOATS_PER_LAYER * layerCount
        if (data.size < need * 4) return emptyList()
        val fb = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN).asFloatBuffer()
        return (0 until layerCount).map { i ->
            val w = FloatArray(FLOATS_PER_LAYER)
            fb.position(i * FLOATS_PER_LAYER)
            fb.get(w, 0, FLOATS_PER_LAYER)
            CnnLayer(w)
        }
    }

    /** Default cnn1 weights — channel-independent mild sharpen (sum=1, brightness preserved).
     *  diag (oc==ic) = [0,-0.5,0, -0.5,3,-0.5, 0,-0.5,0]. */
    fun cnn1DefaultWeights(): FloatArray {
        val kernel = floatArrayOf(0f, -0.5f, 0f, -0.5f, 3f, -0.5f, 0f, -0.5f, 0f)
        val w = FloatArray(FLOATS_PER_LAYER)
        for (oc in 0 until 3) {
            val ic = oc // channel-independent
            for (k in 0 until 9) w[oc * 27 + ic * 9 + k] = kernel[k]
        }
        return w
    }

    /** Synthetic identity layers (oc==ic center=1) — verifies the multi-layer pipeline. */
    fun identityLayers(count: Int): List<CnnLayer> = (0 until count).map {
        val w = FloatArray(FLOATS_PER_LAYER)
        for (c in 0 until 3) w[c * 27 + c * 9 + 4] = 1f
        CnnLayer(w)
    }
}
