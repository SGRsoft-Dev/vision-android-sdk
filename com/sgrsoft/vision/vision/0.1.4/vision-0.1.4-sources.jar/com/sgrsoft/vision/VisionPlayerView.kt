package com.sgrsoft.vision

import android.content.Context
import android.util.AttributeSet
import android.widget.FrameLayout
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

// View host — wraps a Media3 PlayerView and applies SGR Vision enhancement to its player.
// (Compose users can wrap this in AndroidView { VisionPlayerView(it) }.)
@UnstableApi
class VisionPlayerView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
) : FrameLayout(context, attrs) {

    val playerView = PlayerView(context).also { addView(it) }
    private var enhancer: VisionEnhancer? = null

    /** Attach an ExoPlayer and enable enhancement with [options].
     *  When [options.licenseKey] is set, [onLicense] reports verification state. */
    fun setPlayer(
        player: ExoPlayer,
        options: VisionOptions,
        onLicense: ((LicenseState) -> Unit)? = null,
    ) {
        playerView.player = player
        enhancer?.destroy()
        enhancer = VisionEnhancer(player, options, context, onLicense = onLicense)
    }

    /** Update enhancement options live. */
    fun update(options: VisionOptions) { enhancer?.update(options) }

    fun release() {
        enhancer?.destroy(); enhancer = null
        playerView.player = null
    }
}
