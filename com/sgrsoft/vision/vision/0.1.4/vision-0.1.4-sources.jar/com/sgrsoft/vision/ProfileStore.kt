package com.sgrsoft.vision

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

// Loads spec/profiles.json (bundled as a classpath resource) — the language-neutral
// single source of truth shared with web/iOS. We never hardcode profile numbers.

@Serializable
internal data class ProfileSpec(
    val sharpen: Double,
    val contrast: Double,
    val cleanup: Double,
    val anime: Double,
    val gamma: Double,
    val localContrast: Double,
    val darkLift: Double,
    val upscale: Upscale,
    val edge: Edge,
    val cnn1: Boolean,
    val scanline: Scanline,
) {
    @Serializable data class Upscale(val enabled: Boolean, val algorithm: String)
    @Serializable data class Edge(val algorithm: String, val strength: Double)
    @Serializable data class Scanline(val enabled: Boolean, val intensity: Double, val spacing: Double)
}

@Serializable
internal data class ProfileSpecFile(
    val version: String,
    val profiles: Map<String, ProfileSpec>,
    val profileList: List<String>,
    val highResDisplay: HighRes,
    val lowEnd: LowEnd,
    val scaleAttenuation: ScaleAtten,
) {
    @Serializable data class HighRes(val thresholdPx: Double)
    @Serializable data class LowEnd(val attenuation: Attenuation) {
        @Serializable data class Attenuation(
            val sharpen: Double, val cleanup: Double, val anime: Double, val contrast: Double,
        )
    }
    @Serializable data class ScaleAtten(val rule: Rule) {
        @Serializable data class Rule(
            val thresholdScale: Double,
            val atOrBelowThreshold: Double,
        )
    }
}

internal object ProfileStore {
    private val json = Json { ignoreUnknownKeys = true; isLenient = true }

    val spec: ProfileSpecFile by lazy {
        val stream = ProfileStore::class.java.getResourceAsStream("/profiles.json")
            ?: error("SGRVision: profiles.json resource missing")
        json.decodeFromString(ProfileSpecFile.serializer(), stream.bufferedReader().use { it.readText() })
    }

    val version: String get() = spec.version
    val profileList: List<String> get() = spec.profileList

    /** Resolve a profile name to its spec, applying the high-res conservative variant
     *  for default/detail exactly like the web SDK (getProfileDefaults). */
    fun resolve(profile: VisionProfile, highRes: Boolean): ProfileSpec {
        val key = if (highRes && (profile == VisionProfile.`default` || profile == VisionProfile.detail))
            "${profile.raw}@conservative" else profile.raw
        return spec.profiles[key] ?: spec.profiles.getValue("default")
    }
}
