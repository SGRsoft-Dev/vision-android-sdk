package com.sgrsoft.vision

// Public namespace — version + shared-spec metadata. Mirrors iOS VisionSDK.
object VisionSdk {
    /** SDK version (package release; distinct from the spec version). */
    const val version: String = "0.1.8"

    /** Profile spec version bundled from spec/profiles.json. */
    val specVersion: String get() = ProfileStore.version

    /** Available profile names (from the shared spec). */
    val profiles: List<String> get() = ProfileStore.profileList
}

// License verification states (mirror web/iOS). Network client lands in Phase 4.
enum class LicenseState { none, pending, ok, invalid }
