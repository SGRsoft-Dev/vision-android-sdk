package com.sgrsoft.vision

// Mirror of the web SDK VideoEnhancementOptions (src/core/types.ts) and the iOS
// VisionOptions — same names, same value ranges. See spec/profiles.json.

enum class VisionProfile {
    off, `default`, detail, ott, education, cctv, anime, oled, retro,
    entertainment, interview, idol;

    val raw: String get() = name

    companion object {
        fun from(raw: String): VisionProfile = entries.firstOrNull { it.name == raw } ?: `default`
    }
}

enum class VisionRenderer { auto, gles, vulkan }

enum class UpscaleAlgorithm {
    none, nearest, bilinear, lanczos, fsr;

    companion object {
        // Web aliases normalized on decode (lanczos2 -> lanczos, easu -> fsr).
        fun normalizing(raw: String): UpscaleAlgorithm = when (raw) {
            "lanczos2" -> lanczos
            "easu" -> fsr
            else -> entries.firstOrNull { it.name == raw } ?: none
        }
    }
}

enum class UpscaleTarget(val raw: String) {
    source("source"), p720("720p"), p1080("1080p"), p1440("1440p"),
    x2("2x"), x3("3x"), custom("custom")
}

enum class EdgeAlgorithm { off, classic, rcas }

data class ScanlineParams(
    val enabled: Boolean? = null,
    val intensity: Double? = null,
    val spacing: Double? = null,
)

data class UpscaleParams(
    val enabled: Boolean? = null,
    val algorithm: UpscaleAlgorithm? = null,
    val target: UpscaleTarget? = null,
    val width: Int? = null,
    val height: Int? = null,
    val sharpness: Double? = null,   // RCAS shortcut, 0..~0.2
)

data class EdgeEnhancementParams(
    val enabled: Boolean? = null,
    val algorithm: EdgeAlgorithm? = null,
    val strength: Double? = null,    // 0..1
)

data class Cnn1Params(val enabled: Boolean? = null)

/** Multi-layer CNN — 81 floats/layer, [c_out][c_in][k], k = dy*3+dx. */
data class CnnLayer(val weights: FloatArray) {
    override fun equals(other: Any?) =
        this === other || (other is CnnLayer && weights.contentEquals(other.weights))
    override fun hashCode() = weights.contentHashCode()
}

data class CnnParams(val enabled: Boolean? = null, val layers: List<CnnLayer>? = null)

/** Mirror of web VideoEnhancementOptions / iOS VisionOptions. */
data class VisionOptions(
    val enabled: Boolean = true,
    val profile: VisionProfile? = VisionProfile.`default`,
    // Individual strengths — override profile defaults when set.
    val sharpen: Double? = null,        // 0..1
    val contrast: Double? = null,       // 0..1
    val cleanup: Double? = null,        // 0..1
    val bilateral: Double? = null,      // 0..1 (wide-radius edge-preserving smooth — 백옥 피부)
    val anime: Double? = null,          // 0..1
    val gamma: Double? = null,          // 0.5..2.0
    val localContrast: Double? = null,  // 0..1
    val darkLift: Double? = null,       // 0..1
    val saturation: Double? = null,     // 0..1 (chroma boost — vivid primary colors)
    val scanline: ScanlineParams? = null,
    val upscale: UpscaleParams? = null,
    val edgeEnhancement: EdgeEnhancementParams? = null,
    val cnn1: Cnn1Params? = null,
    val cnn: CnnParams? = null,
    val renderer: VisionRenderer? = null,
    val autoReduceOnLowEnd: Boolean? = null,   // default true
    // License — when set, effects stay off until validation passes (original plays).
    val licenseKey: String? = null,
)

/** Normalized GPU uniforms (mirror iOS EnhancementUniforms / web resolveProfileUniforms). */
data class EnhancementUniforms(
    var sharpen: Double = 0.0,
    var contrast: Double = 0.0,
    var cleanup: Double = 0.0,
    var bilateral: Double = 0.0,
    var anime: Double = 0.0,
    var gamma: Double = 1.0,
    var localContrast: Double = 0.0,
    var darkLift: Double = 0.0,
    var saturation: Double = 0.0,
    var scanlineIntensity: Double = 0.0,
    var scanlineSpacing: Double = 3.0,
    var upscaleEnabled: Boolean = false,
    var upscaleAlgorithm: UpscaleAlgorithm = UpscaleAlgorithm.none,
    var rcasEnabled: Boolean = false,
    var rcasSharpness: Double = 0.0,
    var cnn1Enabled: Boolean = false,
)
