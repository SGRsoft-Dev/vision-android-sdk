package com.sgrsoft.vision

// Port of web src/core/EnhancementPipeline.ts + resolveProfileUniforms (and the iOS
// EnhancementPipeline.swift). Profile + user options -> normalized uniforms, with
// low-end attenuation. All baseline numbers come from ProfileStore (profiles.json).

class EnhancementPipeline(
    options: VisionOptions? = null,
    deviceInfo: DeviceInfo = DeviceInfo.default(),
) {
    private var options: VisionOptions? = options
    private val lowEnd = deviceInfo.isLowEnd
    private val highRes = deviceInfo.isHighResDisplay

    var uniforms: EnhancementUniforms = compute(options, highRes, lowEnd)
        private set

    fun update(newOptions: VisionOptions?): Boolean {
        if (newOptions == options) return false
        options = newOptions
        uniforms = compute(newOptions, highRes, lowEnd)
        return true
    }

    val isCnnEnabled: Boolean
        get() {
            val layers = options?.cnn?.layers ?: return false
            return (options?.cnn?.enabled ?: false) && layers.isNotEmpty()
        }

    /** Whether effects are actually applied (mirror web/iOS isEnabled). */
    val isEnabled: Boolean
        get() {
            val o = options ?: return false
            if (!o.enabled || o.profile == VisionProfile.off) return false
            val u = uniforms
            val active = (u.sharpen + u.cleanup + u.bilateral + u.contrast + u.anime + u.scanlineIntensity +
                u.localContrast + u.darkLift + u.saturation) > 0.001
            return active || u.gamma != 1.0 || u.upscaleEnabled || u.rcasEnabled || u.cnn1Enabled || isCnnEnabled
        }

    companion object {
        /** Large-upscale safety attenuation (computeScaleAttenuation). */
        fun scaleAttenuation(vw: Double, vh: Double, outW: Double, outH: Double): Double {
            if (vw <= 0 || vh <= 0 || outW <= 0 || outH <= 0) return 1.0
            val scale = maxOf(outW / vw, outH / vh)
            val rule = ProfileStore.spec.scaleAttenuation.rule
            if (scale <= rule.thresholdScale) return rule.atOrBelowThreshold
            return maxOf(0.4, minOf(1.0, 2.5 / scale))
        }

        private fun clamp(v: Double, lo: Double, hi: Double) = minOf(hi, maxOf(lo, v))

        private fun compute(opts: VisionOptions?, highRes: Boolean, lowEnd: Boolean): EnhancementUniforms {
            val base = resolve(opts, highRes)
            val reduce = (opts?.autoReduceOnLowEnd ?: true) && lowEnd
            if (!reduce) return base
            val a = ProfileStore.spec.lowEnd.attenuation
            return base.copy(
                sharpen = base.sharpen * a.sharpen,
                cleanup = base.cleanup * a.cleanup,
                bilateral = base.bilateral * a.cleanup,   // 평활화 — cleanup 과 동일 감쇠.
                anime = base.anime * a.anime,
                contrast = base.contrast * a.contrast,
            )
        }

        private fun resolve(opts: VisionOptions?, highRes: Boolean): EnhancementUniforms {
            if (opts == null || !opts.enabled) return uniformsFrom(ProfileStore.spec.profiles.getValue("off"))
            val profile = opts.profile ?: VisionProfile.`default`
            if (profile == VisionProfile.off) return uniformsFrom(ProfileStore.spec.profiles.getValue("off"))

            val spec = ProfileStore.resolve(profile, highRes)
            val u = uniformsFrom(spec)

            // --- Upscale (alias normalized, none -> lanczos when forced on) ---
            val up = opts.upscale
            val upOn = up?.enabled ?: u.upscaleEnabled
            val upAlgoRaw = up?.algorithm ?: u.upscaleAlgorithm
            val upAlgo = if (upOn) {
                if (upAlgoRaw == UpscaleAlgorithm.none) UpscaleAlgorithm.lanczos else upAlgoRaw
            } else UpscaleAlgorithm.none

            // --- Edge: edgeEnhancement > upscale.sharpness shortcut > legacy individual ---
            val edge = opts.edgeEnhancement
            val sharpness = up?.sharpness
            if (edge != null) {
                val explicitlyOff = (edge.enabled == false) || (edge.algorithm == EdgeAlgorithm.off)
                val algorithm = if (explicitlyOff) EdgeAlgorithm.off else (edge.algorithm ?: specEdgeAlgo(spec))
                val strength = clamp(edge.strength ?: spec.edge.strength, 0.0, 1.0)
                when (algorithm) {
                    EdgeAlgorithm.classic -> { u.sharpen = strength; u.rcasEnabled = false; u.rcasSharpness = 0.0 }
                    EdgeAlgorithm.rcas -> { u.sharpen = 0.0; u.rcasEnabled = strength > 0; u.rcasSharpness = strength }
                    EdgeAlgorithm.off -> { u.sharpen = 0.0; u.rcasEnabled = false; u.rcasSharpness = 0.0 }
                }
            } else if (sharpness != null) {
                u.sharpen = clamp(opts.sharpen ?: u.sharpen, 0.0, 1.0)
                val sc = clamp(sharpness, 0.0, 1.0)
                u.rcasEnabled = sc > 0; u.rcasSharpness = sc
            } else {
                u.sharpen = clamp(opts.sharpen ?: u.sharpen, 0.0, 1.0)
            }

            // --- Individual strength overrides ---
            u.contrast = clamp(opts.contrast ?: u.contrast, 0.0, 1.0)
            u.cleanup = clamp(opts.cleanup ?: u.cleanup, 0.0, 1.0)
            u.bilateral = clamp(opts.bilateral ?: u.bilateral, 0.0, 1.0)
            u.anime = clamp(opts.anime ?: u.anime, 0.0, 1.0)
            u.gamma = clamp(opts.gamma ?: u.gamma, 0.5, 2.0)
            u.localContrast = clamp(opts.localContrast ?: u.localContrast, 0.0, 1.0)
            u.darkLift = clamp(opts.darkLift ?: u.darkLift, 0.0, 1.0)
            u.saturation = clamp(opts.saturation ?: u.saturation, 0.0, 1.0)

            // --- Scanline ---
            opts.scanline?.let { scan ->
                val on = scan.enabled ?: false
                u.scanlineIntensity = clamp(if (on) (scan.intensity ?: 0.35) else 0.0, 0.0, 1.0)
                u.scanlineSpacing = maxOf(1.0, scan.spacing ?: 3.0)
            }

            u.upscaleEnabled = upOn && upAlgo != UpscaleAlgorithm.none
            u.upscaleAlgorithm = upAlgo

            opts.cnn1?.let { u.cnn1Enabled = it.enabled ?: u.cnn1Enabled }
            return u
        }

        private fun specEdgeAlgo(s: ProfileSpec): EdgeAlgorithm =
            EdgeAlgorithm.entries.firstOrNull { it.name == s.edge.algorithm } ?: EdgeAlgorithm.off

        // ProfileSpec -> EnhancementUniforms (uniformsFromDefaults).
        private fun uniformsFrom(d: ProfileSpec): EnhancementUniforms {
            val algo = EdgeAlgorithm.entries.firstOrNull { it.name == d.edge.algorithm } ?: EdgeAlgorithm.off
            val isRcas = algo == EdgeAlgorithm.rcas && d.edge.strength > 0
            val isClassic = algo == EdgeAlgorithm.classic && d.edge.strength > 0
            return EnhancementUniforms(
                sharpen = if (isClassic) d.edge.strength else d.sharpen,
                contrast = d.contrast,
                cleanup = d.cleanup,
                bilateral = d.bilateral,
                anime = d.anime,
                gamma = d.gamma,
                localContrast = d.localContrast,
                darkLift = d.darkLift,
                saturation = d.saturation,
                scanlineIntensity = if (d.scanline.enabled) d.scanline.intensity else 0.0,
                scanlineSpacing = d.scanline.spacing,
                upscaleEnabled = d.upscale.enabled,
                upscaleAlgorithm = UpscaleAlgorithm.normalizing(d.upscale.algorithm),
                rcasEnabled = isRcas,
                rcasSharpness = if (isRcas) d.edge.strength else 0.0,
                cnn1Enabled = d.cnn1,
            )
        }
    }
}

/** Device capability snapshot (mirrors detectLowEnd / isHighResDisplay). */
data class DeviceInfo(
    val cores: Int,
    val memoryGB: Double,
    val isMobile: Boolean,
    val displayWidthPx: Double,
) {
    val isLowEnd: Boolean
        get() {
            if (cores <= 2) return true
            if (memoryGB <= 2) return true
            if (isMobile && cores <= 4 && memoryGB <= 4) return true
            return false
        }

    val isHighResDisplay: Boolean
        get() = displayWidthPx >= ProfileStore.spec.highResDisplay.thresholdPx

    companion object {
        /** Neutral default for the pure-Kotlin pipeline (Phase 1). The render layer
         *  supplies real memory/display via an Android Context. */
        fun default(): DeviceInfo = DeviceInfo(
            cores = Runtime.getRuntime().availableProcessors(),
            memoryGB = 4.0,
            isMobile = true,
            displayWidthPx = 1080.0,
        )
    }
}
