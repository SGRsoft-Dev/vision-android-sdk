package com.sgrsoft.vision

import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer

// Imperative controller — mirror of the web enhance() handle / iOS VisionEnhancer.
// Attaches the GL effect to an ExoPlayer, maps options -> uniforms/CNN layers, and
// gates effects on license verification (packageName-bound) when a licenseKey is set.

// 낙관적 라이선스 게이팅: 효과를 먼저 켜고 이 grace 후 검증한다.
private const val LICENSE_GRACE_MS = 2000L

@UnstableApi
class VisionEnhancer(
    private val player: ExoPlayer,
    options: VisionOptions,
    private val context: Context? = null,
    deviceInfo: DeviceInfo = DeviceInfo.default(),
    private val onLicense: ((LicenseState) -> Unit)? = null,
) {
    private var options = options
    private val pipeline = EnhancementPipeline(options, deviceInfo)
    private val state = RenderState()
    private val main = Handler(Looper.getMainLooper())

    // License gating: until verified, `licensed` is false -> passthrough (original plays).
    private var licensed = true
    var licenseState: LicenseState = LicenseState.none
        private set

    init {
        val key = options.licenseKey
        if (key != null) {
            // 낙관적 게이팅: 효과를 먼저 켜고 2초 뒤 검증한다(실패 시 effect OFF).
            // app id 는 LicenseClient 가 OS(프로세스)에서 직접 얻고, context.packageName 은
            // 폴백으로만 전달 — 다른 앱 라이선스로 위조 불가.
            licensed = true
            licenseState = LicenseState.pending
            rebuild()
            startLicense(key, context?.applicationContext?.packageName)
        } else {
            licensed = true
            licenseState = LicenseState.none
            rebuild()
        }
        player.setVideoEffects(listOf(VisionGlEffect(state)))
    }

    /** Update options live (no effect rebuild — the effect reads shared state). */
    fun update(newOptions: VisionOptions) {
        options = newOptions
        pipeline.update(newOptions)
        rebuild()
    }

    fun setEnabled(enabled: Boolean) = update(options.copy(enabled = enabled))

    fun getState(): VisionState = VisionState(
        enabled = licensed && pipeline.isEnabled,
        profile = options.profile,
        rendererKind = "gles",
        license = licenseState,
        uniforms = pipeline.uniforms,
    )

    fun destroy() {
        main.removeCallbacksAndMessages(null)   // 대기 중인 라이선스 검증 취소
        player.setVideoEffects(emptyList())
    }

    private fun rebuild() {
        // Passthrough (default uniforms = no-op) until the license check passes.
        if (licensed) {
            state.uniforms = pipeline.uniforms
            state.layers = options.cnn?.layers ?: emptyList()
        } else {
            state.uniforms = EnhancementUniforms()
            state.layers = emptyList()
        }
    }

    private fun startLicense(key: String, fallbackPackageName: String?) {
        // 효과를 먼저 켠 뒤 2초 grace 후 검증/적용(실패면 applyLicense 가 효과를 끔).
        main.postDelayed({
            LicenseClient.cached(key)?.let { applyLicense(it); return@postDelayed }
            Thread {
                val result = LicenseClient.verify(key, fallbackPackageName)
                main.post { applyLicense(result) }
            }.apply { isDaemon = true }.start()
        }, LICENSE_GRACE_MS)
    }

    private fun applyLicense(result: LicenseResult) {
        licensed = result.valid
        licenseState = if (result.valid) LicenseState.ok else LicenseState.invalid
        rebuild()
        onLicense?.invoke(licenseState)
    }
}

data class VisionState(
    val enabled: Boolean,
    val profile: VisionProfile?,
    val rendererKind: String,
    val license: LicenseState,
    val uniforms: EnhancementUniforms,
)
