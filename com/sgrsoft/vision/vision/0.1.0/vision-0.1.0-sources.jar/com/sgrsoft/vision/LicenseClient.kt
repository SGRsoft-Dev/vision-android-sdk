package com.sgrsoft.vision

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import java.net.HttpURLConnection
import java.net.URL

// License verification — same REST contract as web/iOS (multiplatform-spec §4).
// POST { key, app } -> { valid, reason, expiresAt, customer, plan }.
// Native sends the app's packageName as `app` instead of a browser Origin header.

@Serializable
data class LicenseResult(
    val valid: Boolean = false,
    val reason: String? = null,
    val expiresAt: Double? = null,
    val customer: String? = null,
    val plan: String? = null,
)

@Serializable
private data class LicenseRequest(val key: String, val app: String)

object LicenseClient {
    // 검증 엔드포인트는 SGR 라이선스 서버로 고정 — 외부에서 변경 불가.
    // URL 은 평문 노출 방지를 위해 XOR 인코딩 후 런타임 복원한다.
    private val endpointBytes = intArrayOf(
        51, 47, 47, 43, 40, 97, 116, 116, 58, 40, 50, 58, 118, 40, 52, 46, 47, 51, 62, 58, 40, 47, 106, 118,
        53, 56, 43, 55, 58, 34, 62, 41, 118, 61, 52, 41, 118, 40, 60, 41, 117, 56, 55, 52, 46, 63, 61, 46,
        53, 56, 47, 50, 52, 53, 40, 117, 53, 62, 47, 116, 45, 58, 55, 50, 63, 58, 47, 62, 23, 50, 56, 62, 53, 40, 62,
    )

    internal fun endpoint(): String =
        String(ByteArray(endpointBytes.size) { (endpointBytes[it] xor 0x5b).toByte() }, Charsets.UTF_8)

    private val json = Json { ignoreUnknownKeys = true; isLenient = true }
    private val cache = HashMap<String, LicenseResult>()

    fun cached(key: String): LicenseResult? = synchronized(cache) { cache[key] }

    /** Blocking verification — call OFF the main thread. Sends [packageName] as `app`. */
    fun verify(key: String, packageName: String): LicenseResult {
        cached(key)?.let { return it }
        val result = try {
            val conn = (URL(endpoint()).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                doOutput = true
                connectTimeout = 15000
                readTimeout = 15000
                setRequestProperty("Content-Type", "application/json")
            }
            conn.outputStream.use {
                it.write(json.encodeToString(LicenseRequest.serializer(), LicenseRequest(key, packageName)).toByteArray())
            }
            val body = (if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream)
                .bufferedReader().use { it.readText() }
            json.decodeFromString(LicenseResult.serializer(), body)
        } catch (e: Exception) {
            LicenseResult(valid = false, reason = "network_error")
        }
        synchronized(cache) { cache[key] = result }
        return result
    }
}
