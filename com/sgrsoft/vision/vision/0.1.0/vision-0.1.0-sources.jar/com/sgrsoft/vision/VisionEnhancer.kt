package com.sgrsoft.vision

import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer

// Imperative controller — mirror of the web enhance() handle / iOS VisionEnhancer.
// Attaches the GL effect to an ExoPlayer, maps options -> uniforms/CNN layers, and
// gates effects on license verification (packageName-bound) when a licenseKey is set.

@UnstableApi
class VisionEnhancer(
    private val player: ExoPlayer,
    options: VisionOptions,
    private val context: Context? = null,
    deviceInfo: DeviceInfo = DeviceInfo.default(),
    private val onLicense: ((LicenseState) -> Unit)? = null,
) {
    private var options = options
    private val pipeline = EnhancementPipeline(options, deviceInfo)
    private val state = RenderState()
    private val main = Handler(Looper.getMainLooper())

    // License gating: until verified, `licensed` is false -> passthrough (original plays).
    private var licensed = true
    var licenseState: LicenseState = LicenseState.none
        private set

    init {
        val key = options.licenseKey
        if (key != null && context != null) {
            licensed = false
            licenseState = LicenseState.pending
            rebuild()
            startLicense(key, context.packageName)
        } else {
            licensed = true
            licenseState = LicenseState.none
            rebuild()
        }
        player.setVideoEffects(listOf(VisionGlEffect(state)))
    }

    /** Update options live (no effect rebuild — the effect reads shared state). */
    fun update(newOptions: VisionOptions) {
        options = newOptions
        pipeline.update(newOptions)
        rebuild()
    }

    fun setEnabled(enabled: Boolean) = update(options.copy(enabled = enabled))

    fun getState(): VisionState = VisionState(
        enabled = licensed && pipeline.isEnabled,
        profile = options.profile,
        rendererKind = "gles",
        license = licenseState,
        uniforms = pipeline.uniforms,
    )

    fun destroy() {
        player.setVideoEffects(emptyList())
    }

    private fun rebuild() {
        // Passthrough (default uniforms = no-op) until the license check passes.
        if (licensed) {
            state.uniforms = pipeline.uniforms
            state.layers = options.cnn?.layers ?: emptyList()
        } else {
            state.uniforms = EnhancementUniforms()
            state.layers = emptyList()
        }
    }

    private fun startLicense(key: String, packageName: String) {
        LicenseClient.cached(key)?.let { applyLicense(it); return }
        Thread {
            val result = LicenseClient.verify(key, packageName)
            main.post { applyLicense(result) }
        }.apply { isDaemon = true }.start()
    }

    private fun applyLicense(result: LicenseResult) {
        licensed = result.valid
        licenseState = if (result.valid) LicenseState.ok else LicenseState.invalid
        rebuild()
        onLicense?.invoke(licenseState)
    }
}

data class VisionState(
    val enabled: Boolean,
    val profile: VisionProfile?,
    val rendererKind: String,
    val license: LicenseState,
    val uniforms: EnhancementUniforms,
)
