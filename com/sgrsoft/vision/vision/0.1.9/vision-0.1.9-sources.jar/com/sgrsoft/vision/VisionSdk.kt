package com.sgrsoft.vision

// Public namespace — version + shared-spec metadata. Mirrors iOS VisionSDK.
object VisionSdk {
    /** SDK version (package release; distinct from the spec version). */
    const val version: String = "0.1.9"

    /** Profile spec version bundled from spec/profiles.json. */
    val specVersion: String get() = ProfileStore.version

    /** Available profile names (from the shared spec). */
    val profiles: List<String> get() = ProfileStore.profileList

    /** A profile's default edge enhancement (algorithm + strength) from the shared spec.
     *  Mirrors the web SDK getProfileDefaults(profile).edge — lets UIs reflect the
     *  profile's edge values instead of a hardcoded default. */
    fun profileEdgeDefault(profile: VisionProfile, highRes: Boolean = false): EdgeEnhancementParams {
        val e = ProfileStore.resolve(profile, highRes).edge
        return EdgeEnhancementParams(
            enabled = e.algorithm != "off",
            algorithm = EdgeAlgorithm.entries.firstOrNull { it.name == e.algorithm } ?: EdgeAlgorithm.off,
            strength = e.strength,
        )
    }
}

// License verification states (mirror web/iOS). Network client lands in Phase 4.
enum class LicenseState { none, pending, ok, invalid }
